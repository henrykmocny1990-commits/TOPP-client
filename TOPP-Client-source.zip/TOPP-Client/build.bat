@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle build
  goto done
)
set "GDIR=%USERPROFILE%\.topp-gradle"
set "GZIP=%TEMP%\topp-gradle-8.12-bin.zip"
if not exist "%GDIR%\gradle-8.12\bin\gradle.bat" (
  echo Pobieram Gradle 8.12 - wymagane polaczenie z internetem...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.12-bin.zip' -OutFile '%GZIP%'; Expand-Archive -Force '%GZIP%' '%GDIR%'"
  if errorlevel 1 goto failed
)
call "%GDIR%\gradle-8.12\bin\gradle.bat" build
:done
if errorlevel 1 goto failed
echo.
echo GOTOWE! Plik JAR znajdziesz w folderze build\libs.
pause
exit /b 0
:failed
echo.
echo Nie udalo sie zbudowac moda. Sprawdz internet i czy masz Java 21.
pause
exit /b 1
