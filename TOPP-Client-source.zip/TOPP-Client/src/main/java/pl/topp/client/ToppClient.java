package pl.topp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class ToppClient implements ClientModInitializer {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int AQUA = 0xFF55FFFF;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> checkKill(message));
    }

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int x = 8;
        int y = 8;
        int line = 11;
        context.drawTextWithShadow(client.textRenderer, Text.literal("TOPP CLIENT"), x, y, AQUA);
        y += line + 2;

        context.drawTextWithShadow(client.textRenderer,
                Text.literal("FPS: " + client.getCurrentFps()), x, y, WHITE);
        y += line;

        int ping = -1;
        if (client.getNetworkHandler() != null) {
            var entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }
        context.drawTextWithShadow(client.textRenderer,
                Text.literal("PING: " + (ping >= 0 ? ping + " ms" : "--")), x, y, WHITE);
        y += line;

        var pos = client.player.getBlockPos();
        context.drawTextWithShadow(client.textRenderer,
                Text.literal("XYZ: " + pos.getX() + " / " + pos.getY() + " / " + pos.getZ()), x, y, WHITE);
    }

    private static void checkKill(Text message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        String text = message.getString();
        String playerName = client.player.getName().getString();
        boolean mentionsKill = text.contains("was slain by " + playerName)
                || text.contains("was killed by " + playerName)
                || text.contains("was shot by " + playerName)
                || text.contains("został zabity przez " + playerName)
                || text.contains("została zabita przez " + playerName)
                || text.contains("zginął z rąk " + playerName)
                || text.contains("zginęła z rąk " + playerName);

        if (!mentionsKill) return;

        var p = client.player;
        for (int i = 0; i < 24; i++) {
            double angle = (Math.PI * 2.0 * i) / 24.0;
            double radius = 0.8 + (i % 3) * 0.18;
            client.world.addParticle(ParticleTypes.TOTEM_OF_UNDYING,
                    p.getX() + Math.cos(angle) * radius,
                    p.getY() + 0.8 + (i % 4) * 0.25,
                    p.getZ() + Math.sin(angle) * radius,
                    0.0, 0.08, 0.0);
        }
        p.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.5f);
    }
}
