TOPP CLIENT - Minecraft Java 1.21.4 / Fabric

Funkcje:
- Kill Effect: zielono-zloty efekt czasteczek i dzwiek po wykryciu wiadomosci o zabiciu gracza przez Ciebie.
- FPS
- Ping
- Koordynaty XYZ

JAK ZBUDOWAC PLIK JAR:
1. Zainstaluj Java 21 (JDK).
2. Rozpakuj folder TOPP-Client.
3. Kliknij dwa razy build.bat. Przy pierwszym uruchomieniu potrzebny jest internet,
   bo Gradle pobierze wymagane biblioteki Minecraft/Fabric.
4. Gotowy plik bedzie w build\libs\TOPP-Client-1.0.0.jar.
5. Wrzuc ten plik do .minecraft\mods.
6. Uruchom profil Fabric 1.21.4. Wymagany jest tez Fabric API 1.21.4.

UWAGA:
Kill Effect wykrywa typowe wiadomosci czatu o zabiciu. Niektore serwery uzywaja
niestandardowych wiadomosci lub ukrywaja je, wiec na nich efekt moze sie nie uruchomic.
HUD jest wyswietlany w lewym gornym rogu.
